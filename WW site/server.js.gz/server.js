/*Dylan Porter (Partnered with Zachary Kuchar)*/
/*Professor Jackson*/
/*Web-Based Design*/
/*3/26/2018*/

const WebSocket = require('ws');
let wss = new WebSocket.Server({port:3000}, () => {console.log("Server Started");});

let CLIENTS = [];
let clientCounter = 0;

wss.on('connection', function(ws) {
  let tempCounter = clientCounter;
  let tempCounterOther = 1 - clientCounter++;
  
  ws.on('message', function(data) {
    if(!CLIENTS.includes(ws)) {
      if(CLIENTS.length == 0) {
        ws.send("You are the first in this chat room.");
      } else {
        let s = CLIENTS[tempCounterOther].nameVar;
        
        ws.send("You're Joining a chat with: " + s);
        CLIENTS[0].send(data + " has joined the chat.");
        
      }
      ws.nameVar = data;
      CLIENTS.push(ws);
    } else {
      let msgClient = CLIENTS.indexOf(ws);
      CLIENTS[1-msgClient].send(CLIENTS[msgClient].nameVar+ ": " + data);
    }
  });
});
